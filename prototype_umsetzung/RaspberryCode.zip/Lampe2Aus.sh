#!/bin/bash
sudo pigpiod
pigs p 22 0
pigs p 17 0
pigs p 24 0