#!/bin/bash

sudo pigpiod
pigs p 17 215
pigs p 22 90
pigs p 24 100