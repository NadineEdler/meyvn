#!/bin/bash
http-server
$SHELL