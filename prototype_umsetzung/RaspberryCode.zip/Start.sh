#!/bin/bash
sudo killall pigpiod