!/bin/bash

sudo pigpiod
pigs p 25 200
pigs p 23 0
pigs p 27 3