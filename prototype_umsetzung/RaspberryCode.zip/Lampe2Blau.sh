#!/bin/bash

sudo pigpiod
pigs p 17 20
pigs p 22 0
pigs p 24 80