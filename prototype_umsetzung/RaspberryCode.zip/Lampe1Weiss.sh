!/bin/bash

sudo pigpiod
pigs p 25 215
pigs p 23 90
pigs p 27 100